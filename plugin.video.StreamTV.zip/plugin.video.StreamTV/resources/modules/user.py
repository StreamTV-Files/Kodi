import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLlN0cmVhbVRWS29kaQ==')

name = b.b64decode('U3RyZWFtVFYgS29kaQ==')

host = b.b64decode('aHR0cDovL2VpcmVob3N0aW5nLm5ldA==')

port = b.b64decode('ODA4MA==')